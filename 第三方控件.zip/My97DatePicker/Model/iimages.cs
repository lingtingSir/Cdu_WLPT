﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Model
{
    public class iimages
    {
        private int iid;

        public int Iid
        {
            get { return iid; }
            set { iid = value; }
        }
        private int p_iid;

        public int P_iid
        {
            get { return p_iid; }
            set { p_iid = value; }
        }
        private string nname;

        public string Nname
        {
            get { return nname; }
            set { nname = value; }
        }
        private string sex;

        public string Sex
        {
            get { return sex; }
            set { sex = value; }
        }

        private string wworker;

        public string Wworker
        {
            get { return wworker; }
            set { wworker = value; }
        }
        private string yyear;

        public string Yyear
        {
            get { return yyear; }
            set { yyear = value; }
        }
        private string type;

        public string Type
        {
            get { return type; }
            set { type = value; }
        }
        private DateTime pubdate;

        public DateTime Pubdate
        {
            get { return pubdate; }
            set { pubdate = value; }
        }


        private int ttelephone;


        public int Ttelephone
        {
            get { return ttelephone; }
            set { ttelephone = value; }
        }
        private int qqq;

        public int Qqq
        {
            get { return qqq; }
            set { qqq = value; }
        }
        private string eemail;

        public string Eemail
        {
            get { return eemail; }
            set { eemail = value; }
        }
        private string urll;

        public string Urll
        {
            get { return urll; }
            set { urll = value; }
        }
    }
}
